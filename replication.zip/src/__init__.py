import sys
sys.path.append(".")
from __paths__ import *
